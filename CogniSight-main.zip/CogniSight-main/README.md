CogniSight

Evolve AI is thrilled to present ✨'CogniSight: A Workshop on Mastering Video Analytics from Ground Zero'✨ an event that embodies the spirit of innovation and learning. We are joining forces with Ikigai Labs and NEC to provide students an exciting opportunity to delve into the world of Computer Vision, and Video Analytics.


